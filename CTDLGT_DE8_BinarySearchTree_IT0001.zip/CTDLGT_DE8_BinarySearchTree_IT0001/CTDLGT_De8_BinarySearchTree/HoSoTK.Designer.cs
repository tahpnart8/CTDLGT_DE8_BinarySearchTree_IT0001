﻿namespace CTDLGT_De8_BinarySearchTree
{
    partial class HoSoTK
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle4 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle5 = new DataGridViewCellStyle();
            dataGridView1 = new DataGridView();
            AccountID = new DataGridViewTextBoxColumn();
            AccountName = new DataGridViewTextBoxColumn();
            Balance = new DataGridViewTextBoxColumn();
            TransactionNumber = new DataGridViewTextBoxColumn();
            AccountDate = new DataGridViewTextBoxColumn();
            tabControl1 = new TabControl();
            tabPage1 = new TabPage();
            flowLayoutPanel1 = new FlowLayoutPanel();
            panel1 = new Panel();
            Find = new Button();
            button6 = new Button();
            button5 = new Button();
            label15 = new Label();
            ChonNgay2 = new DateTimePicker();
            ChonNgay1 = new DateTimePicker();
            TimeName = new Label();
            EnterTN = new TextBox();
            TextName = new Label();
            label1 = new Label();
            comboBox1 = new ComboBox();
            tabPage2 = new TabPage();
            label20 = new Label();
            dataGridView2 = new DataGridView();
            dataGridViewTextBoxColumn1 = new DataGridViewTextBoxColumn();
            dataGridViewTextBoxColumn2 = new DataGridViewTextBoxColumn();
            dataGridViewTextBoxColumn3 = new DataGridViewTextBoxColumn();
            dataGridViewTextBoxColumn4 = new DataGridViewTextBoxColumn();
            dataGridViewTextBoxColumn5 = new DataGridViewTextBoxColumn();
            panel3 = new Panel();
            label21 = new Label();
            diachi = new TextBox();
            Birth = new DateTimePicker();
            label18 = new Label();
            label19 = new Label();
            email = new TextBox();
            label16 = new Label();
            sdt = new TextBox();
            label17 = new Label();
            TenTK = new TextBox();
            label12 = new Label();
            sotien = new NumericUpDown();
            loaiGD = new ComboBox();
            ThemTK = new Button();
            label11 = new Label();
            label10 = new Label();
            ngayGD = new DateTimePicker();
            label9 = new Label();
            label8 = new Label();
            maGD = new TextBox();
            label7 = new Label();
            CCCD = new TextBox();
            label6 = new Label();
            label5 = new Label();
            panel2 = new Panel();
            missingValue = new Label();
            solanGDxoa = new TextBox();
            soduTKxoa = new TextBox();
            label13 = new Label();
            label14 = new Label();
            NgaylapTKxoa = new DateTimePicker();
            TenTKxoa = new TextBox();
            label3 = new Label();
            label2 = new Label();
            Xoa = new Button();
            Them = new Button();
            ID = new TextBox();
            label4 = new Label();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            tabControl1.SuspendLayout();
            tabPage1.SuspendLayout();
            flowLayoutPanel1.SuspendLayout();
            panel1.SuspendLayout();
            tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView2).BeginInit();
            panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)sotien).BeginInit();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // dataGridView1
            // 
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.AllowUserToDeleteRows = false;
            dataGridView1.BackgroundColor = Color.White;
            dataGridView1.CellBorderStyle = DataGridViewCellBorderStyle.Raised;
            dataGridView1.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = Color.FromArgb(239, 166, 182);
            dataGridViewCellStyle1.Font = new Font("Calibri", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            dataGridViewCellStyle1.ForeColor = Color.Black;
            dataGridViewCellStyle1.SelectionBackColor = Color.FromArgb(64, 64, 64);
            dataGridViewCellStyle1.SelectionForeColor = Color.FromArgb(239, 166, 182);
            dataGridViewCellStyle1.WrapMode = DataGridViewTriState.True;
            dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Columns.AddRange(new DataGridViewColumn[] { AccountID, AccountName, Balance, TransactionNumber, AccountDate });
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = SystemColors.Window;
            dataGridViewCellStyle2.Font = new Font("Calibri", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            dataGridViewCellStyle2.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = Color.FromArgb(243, 198, 242);
            dataGridViewCellStyle2.SelectionForeColor = Color.Black;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.False;
            dataGridView1.DefaultCellStyle = dataGridViewCellStyle2;
            dataGridView1.EnableHeadersVisualStyles = false;
            dataGridView1.GridColor = Color.Black;
            dataGridView1.Location = new Point(2, 3);
            dataGridView1.Margin = new Padding(2, 3, 2, 3);
            dataGridView1.Name = "dataGridView1";
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = Color.FromArgb(224, 224, 224);
            dataGridViewCellStyle3.Font = new Font("Calibri", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            dataGridViewCellStyle3.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = Color.FromArgb(117, 84, 174);
            dataGridViewCellStyle3.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.True;
            dataGridView1.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            dataGridView1.RowHeadersWidth = 62;
            dataGridView1.Size = new Size(662, 302);
            dataGridView1.TabIndex = 0;
            dataGridView1.CellClick += dataGridView1_CellContentClick;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick_1;
            // 
            // AccountID
            // 
            AccountID.AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
            AccountID.HeaderText = "Số Tài khoản";
            AccountID.MinimumWidth = 8;
            AccountID.Name = "AccountID";
            AccountID.ReadOnly = true;
            AccountID.Width = 120;
            // 
            // AccountName
            // 
            AccountName.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            AccountName.DataPropertyName = "(none)";
            AccountName.HeaderText = "Tên Tài khoản";
            AccountName.MinimumWidth = 8;
            AccountName.Name = "AccountName";
            AccountName.ReadOnly = true;
            AccountName.Width = 109;
            // 
            // Balance
            // 
            Balance.AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
            Balance.HeaderText = "Số dư";
            Balance.MinimumWidth = 8;
            Balance.Name = "Balance";
            Balance.ReadOnly = true;
            Balance.Width = 90;
            // 
            // TransactionNumber
            // 
            TransactionNumber.AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
            TransactionNumber.HeaderText = "Số giao dịch";
            TransactionNumber.MinimumWidth = 8;
            TransactionNumber.Name = "TransactionNumber";
            TransactionNumber.ReadOnly = true;
            TransactionNumber.Width = 115;
            // 
            // AccountDate
            // 
            AccountDate.AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
            AccountDate.HeaderText = "Ngày lập Tài khoản";
            AccountDate.MinimumWidth = 8;
            AccountDate.Name = "AccountDate";
            AccountDate.ReadOnly = true;
            AccountDate.Width = 150;
            // 
            // tabControl1
            // 
            tabControl1.Controls.Add(tabPage1);
            tabControl1.Controls.Add(tabPage2);
            tabControl1.Font = new Font("Calibri", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            tabControl1.ItemSize = new Size(69, 23);
            tabControl1.Location = new Point(2, 3);
            tabControl1.Margin = new Padding(2, 3, 2, 3);
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new Size(730, 449);
            tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            tabPage1.BackColor = SystemColors.ControlLightLight;
            tabPage1.Controls.Add(flowLayoutPanel1);
            tabPage1.Controls.Add(panel1);
            tabPage1.Location = new Point(4, 27);
            tabPage1.Margin = new Padding(2, 3, 2, 3);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new Padding(2, 3, 2, 3);
            tabPage1.Size = new Size(722, 418);
            tabPage1.TabIndex = 0;
            tabPage1.Text = "Tìm kiếm";
            // 
            // flowLayoutPanel1
            // 
            flowLayoutPanel1.AutoScroll = true;
            flowLayoutPanel1.Controls.Add(dataGridView1);
            flowLayoutPanel1.Location = new Point(5, 126);
            flowLayoutPanel1.Margin = new Padding(2, 3, 2, 3);
            flowLayoutPanel1.Name = "flowLayoutPanel1";
            flowLayoutPanel1.Size = new Size(688, 294);
            flowLayoutPanel1.TabIndex = 3;
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(141, 144, 226);
            panel1.Controls.Add(Find);
            panel1.Controls.Add(button6);
            panel1.Controls.Add(button5);
            panel1.Controls.Add(label15);
            panel1.Controls.Add(ChonNgay2);
            panel1.Controls.Add(ChonNgay1);
            panel1.Controls.Add(TimeName);
            panel1.Controls.Add(EnterTN);
            panel1.Controls.Add(TextName);
            panel1.Controls.Add(label1);
            panel1.Controls.Add(comboBox1);
            panel1.Location = new Point(2, 3);
            panel1.Margin = new Padding(2, 3, 2, 3);
            panel1.Name = "panel1";
            panel1.Size = new Size(689, 120);
            panel1.TabIndex = 2;
            panel1.Paint += panel1_Paint;
            // 
            // Find
            // 
            Find.BackColor = Color.FromArgb(255, 255, 192);
            Find.Cursor = Cursors.Hand;
            Find.Font = new Font("Calibri", 8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Find.ForeColor = Color.FromArgb(37, 57, 146);
            Find.Location = new Point(288, 78);
            Find.Margin = new Padding(2, 3, 2, 3);
            Find.Name = "Find";
            Find.Size = new Size(57, 27);
            Find.TabIndex = 10;
            Find.Text = "Tìm";
            Find.UseVisualStyleBackColor = false;
            Find.Visible = false;
            Find.Click += button7_Click;
            // 
            // button6
            // 
            button6.Location = new Point(600, 74);
            button6.Margin = new Padding(2, 3, 2, 3);
            button6.Name = "button6";
            button6.Size = new Size(77, 31);
            button6.TabIndex = 9;
            button6.Text = "Cũ nhất";
            button6.UseVisualStyleBackColor = true;
            button6.Click += button6_Click;
            // 
            // button5
            // 
            button5.Location = new Point(600, 17);
            button5.Margin = new Padding(2, 3, 2, 3);
            button5.Name = "button5";
            button5.Size = new Size(77, 32);
            button5.TabIndex = 8;
            button5.Text = "Mới nhất";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click;
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.ForeColor = SystemColors.ControlLightLight;
            label15.Location = new Point(540, 53);
            label15.Margin = new Padding(2, 0, 2, 0);
            label15.Name = "label15";
            label15.Size = new Size(56, 18);
            label15.TabIndex = 7;
            label15.Text = "Sắp xếp";
            // 
            // ChonNgay2
            // 
            ChonNgay2.CalendarTitleBackColor = Color.FromArgb(230, 255, 242);
            ChonNgay2.Format = DateTimePickerFormat.Short;
            ChonNgay2.Location = new Point(378, 37);
            ChonNgay2.Margin = new Padding(2, 3, 2, 3);
            ChonNgay2.Name = "ChonNgay2";
            ChonNgay2.Size = new Size(146, 26);
            ChonNgay2.TabIndex = 6;
            ChonNgay2.Visible = false;
            // 
            // ChonNgay1
            // 
            ChonNgay1.CalendarTitleBackColor = Color.FromArgb(230, 255, 242);
            ChonNgay1.Format = DateTimePickerFormat.Short;
            ChonNgay1.Location = new Point(196, 37);
            ChonNgay1.Margin = new Padding(2, 3, 2, 3);
            ChonNgay1.Name = "ChonNgay1";
            ChonNgay1.Size = new Size(146, 26);
            ChonNgay1.TabIndex = 0;
            ChonNgay1.Visible = false;
            // 
            // TimeName
            // 
            TimeName.AutoSize = true;
            TimeName.ForeColor = SystemColors.ControlLightLight;
            TimeName.Location = new Point(378, 15);
            TimeName.Margin = new Padding(2, 0, 2, 0);
            TimeName.Name = "TimeName";
            TimeName.Size = new Size(76, 18);
            TimeName.TabIndex = 5;
            TimeName.Text = "TimeName";
            TimeName.Visible = false;
            // 
            // EnterTN
            // 
            EnterTN.Location = new Point(199, 37);
            EnterTN.Margin = new Padding(2, 3, 2, 3);
            EnterTN.Name = "EnterTN";
            EnterTN.Size = new Size(146, 26);
            EnterTN.TabIndex = 4;
            EnterTN.Visible = false;
            // 
            // TextName
            // 
            TextName.AutoSize = true;
            TextName.ForeColor = SystemColors.ControlLightLight;
            TextName.Location = new Point(196, 15);
            TextName.Margin = new Padding(2, 0, 2, 0);
            TextName.Name = "TextName";
            TextName.Size = new Size(71, 18);
            TextName.TabIndex = 3;
            TextName.Text = "TextName";
            TextName.Visible = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Calibri", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = SystemColors.ControlLightLight;
            label1.Location = new Point(16, 17);
            label1.Margin = new Padding(2, 0, 2, 0);
            label1.Name = "label1";
            label1.Size = new Size(112, 21);
            label1.TabIndex = 2;
            label1.Text = "Tìm kiếm theo";
            // 
            // comboBox1
            // 
            comboBox1.FlatStyle = FlatStyle.Flat;
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { " Số Tài khoản", " Tên Tài khoản", " Thời gian" });
            comboBox1.Location = new Point(16, 39);
            comboBox1.Margin = new Padding(2, 3, 2, 3);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(147, 26);
            comboBox1.TabIndex = 1;
            comboBox1.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
            comboBox1.SelectionChangeCommitted += ComboBox_SelectedChanged;
            // 
            // tabPage2
            // 
            tabPage2.BackColor = SystemColors.ControlLightLight;
            tabPage2.Controls.Add(label20);
            tabPage2.Controls.Add(dataGridView2);
            tabPage2.Controls.Add(panel3);
            tabPage2.Controls.Add(panel2);
            tabPage2.Location = new Point(4, 27);
            tabPage2.Margin = new Padding(2, 3, 2, 3);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new Padding(2, 3, 2, 3);
            tabPage2.Size = new Size(722, 418);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "Chỉnh sửa";
            // 
            // label20
            // 
            label20.AutoSize = true;
            label20.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label20.ForeColor = Color.Green;
            label20.Location = new Point(315, 327);
            label20.Margin = new Padding(2, 0, 2, 0);
            label20.Name = "label20";
            label20.Size = new Size(97, 20);
            label20.TabIndex = 6;
            label20.Text = "XEM TRƯỚC";
            // 
            // dataGridView2
            // 
            dataGridView2.AllowUserToAddRows = false;
            dataGridView2.AllowUserToDeleteRows = false;
            dataGridView2.BackgroundColor = Color.White;
            dataGridView2.CellBorderStyle = DataGridViewCellBorderStyle.Raised;
            dataGridView2.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle4.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.BackColor = Color.FromArgb(239, 166, 182);
            dataGridViewCellStyle4.Font = new Font("Calibri", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            dataGridViewCellStyle4.ForeColor = Color.Black;
            dataGridViewCellStyle4.SelectionBackColor = Color.Black;
            dataGridViewCellStyle4.SelectionForeColor = Color.FromArgb(239, 166, 182);
            dataGridViewCellStyle4.WrapMode = DataGridViewTriState.True;
            dataGridView2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            dataGridView2.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView2.Columns.AddRange(new DataGridViewColumn[] { dataGridViewTextBoxColumn1, dataGridViewTextBoxColumn2, dataGridViewTextBoxColumn3, dataGridViewTextBoxColumn4, dataGridViewTextBoxColumn5 });
            dataGridViewCellStyle5.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = SystemColors.Window;
            dataGridViewCellStyle5.Font = new Font("Calibri", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            dataGridViewCellStyle5.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle5.SelectionBackColor = Color.FromArgb(243, 198, 242);
            dataGridViewCellStyle5.SelectionForeColor = Color.Black;
            dataGridViewCellStyle5.WrapMode = DataGridViewTriState.False;
            dataGridView2.DefaultCellStyle = dataGridViewCellStyle5;
            dataGridView2.EnableHeadersVisualStyles = false;
            dataGridView2.Location = new Point(2, 349);
            dataGridView2.Margin = new Padding(2, 3, 2, 3);
            dataGridView2.Name = "dataGridView2";
            dataGridView2.RowHeadersWidth = 62;
            dataGridView2.ScrollBars = ScrollBars.None;
            dataGridView2.Size = new Size(689, 69);
            dataGridView2.TabIndex = 5;
            dataGridView2.CellClick += dataGridView2_CellContentClick;
            dataGridView2.CellContentClick += dataGridView2_CellContentClick_1;
            // 
            // dataGridViewTextBoxColumn1
            // 
            dataGridViewTextBoxColumn1.AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
            dataGridViewTextBoxColumn1.HeaderText = "Số Tài khoản";
            dataGridViewTextBoxColumn1.MinimumWidth = 8;
            dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            dataGridViewTextBoxColumn1.ReadOnly = true;
            dataGridViewTextBoxColumn1.Width = 120;
            // 
            // dataGridViewTextBoxColumn2
            // 
            dataGridViewTextBoxColumn2.AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
            dataGridViewTextBoxColumn2.HeaderText = "Tên Tài khoản";
            dataGridViewTextBoxColumn2.MinimumWidth = 8;
            dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            dataGridViewTextBoxColumn2.ReadOnly = true;
            dataGridViewTextBoxColumn2.Width = 150;
            // 
            // dataGridViewTextBoxColumn3
            // 
            dataGridViewTextBoxColumn3.AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
            dataGridViewTextBoxColumn3.HeaderText = "Số dư";
            dataGridViewTextBoxColumn3.MinimumWidth = 8;
            dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            dataGridViewTextBoxColumn3.ReadOnly = true;
            dataGridViewTextBoxColumn3.Width = 90;
            // 
            // dataGridViewTextBoxColumn4
            // 
            dataGridViewTextBoxColumn4.AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
            dataGridViewTextBoxColumn4.HeaderText = "Số giao dịch";
            dataGridViewTextBoxColumn4.MinimumWidth = 8;
            dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            dataGridViewTextBoxColumn4.ReadOnly = true;
            dataGridViewTextBoxColumn4.Width = 115;
            // 
            // dataGridViewTextBoxColumn5
            // 
            dataGridViewTextBoxColumn5.HeaderText = "Ngày lập Tài khoản";
            dataGridViewTextBoxColumn5.MinimumWidth = 8;
            dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            dataGridViewTextBoxColumn5.ReadOnly = true;
            dataGridViewTextBoxColumn5.Width = 190;
            // 
            // panel3
            // 
            panel3.BackColor = Color.FromArgb(141, 144, 226);
            panel3.Controls.Add(label21);
            panel3.Controls.Add(diachi);
            panel3.Controls.Add(Birth);
            panel3.Controls.Add(label18);
            panel3.Controls.Add(label19);
            panel3.Controls.Add(email);
            panel3.Controls.Add(label16);
            panel3.Controls.Add(sdt);
            panel3.Controls.Add(label17);
            panel3.Controls.Add(TenTK);
            panel3.Controls.Add(label12);
            panel3.Controls.Add(sotien);
            panel3.Controls.Add(loaiGD);
            panel3.Controls.Add(ThemTK);
            panel3.Controls.Add(label11);
            panel3.Controls.Add(label10);
            panel3.Controls.Add(ngayGD);
            panel3.Controls.Add(label9);
            panel3.Controls.Add(label8);
            panel3.Controls.Add(maGD);
            panel3.Controls.Add(label7);
            panel3.Controls.Add(CCCD);
            panel3.Controls.Add(label6);
            panel3.Controls.Add(label5);
            panel3.Location = new Point(2, 131);
            panel3.Margin = new Padding(2, 3, 2, 3);
            panel3.Name = "panel3";
            panel3.Size = new Size(689, 193);
            panel3.TabIndex = 4;
            panel3.Paint += panel3_Paint;
            // 
            // label21
            // 
            label21.AutoSize = true;
            label21.Font = new Font("Segoe UI", 8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label21.ForeColor = Color.Tomato;
            label21.Location = new Point(357, 152);
            label21.Margin = new Padding(2, 0, 2, 0);
            label21.Name = "label21";
            label21.Size = new Size(27, 19);
            label21.TabIndex = 16;
            label21.Text = "Lỗi";
            label21.Visible = false;
            // 
            // diachi
            // 
            diachi.BorderStyle = BorderStyle.FixedSingle;
            diachi.Enabled = false;
            diachi.Location = new Point(182, 105);
            diachi.Margin = new Padding(2, 3, 2, 3);
            diachi.Name = "diachi";
            diachi.Size = new Size(137, 26);
            diachi.TabIndex = 32;
            // 
            // Birth
            // 
            Birth.CalendarTitleBackColor = Color.FromArgb(230, 255, 242);
            Birth.Enabled = false;
            Birth.Format = DateTimePickerFormat.Short;
            Birth.Location = new Point(18, 105);
            Birth.Margin = new Padding(2, 3, 2, 3);
            Birth.Name = "Birth";
            Birth.Size = new Size(138, 26);
            Birth.TabIndex = 31;
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Font = new Font("Calibri", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label18.ForeColor = Color.White;
            label18.Location = new Point(182, 81);
            label18.Margin = new Padding(2, 0, 2, 0);
            label18.Name = "label18";
            label18.Size = new Size(57, 21);
            label18.TabIndex = 30;
            label18.Text = "Địa chỉ";
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.Font = new Font("Calibri", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label19.ForeColor = Color.White;
            label19.Location = new Point(18, 81);
            label19.Margin = new Padding(2, 0, 2, 0);
            label19.Name = "label19";
            label19.Size = new Size(78, 21);
            label19.TabIndex = 29;
            label19.Text = "Ngày sinh";
            // 
            // email
            // 
            email.BorderStyle = BorderStyle.FixedSingle;
            email.Enabled = false;
            email.Location = new Point(182, 156);
            email.Margin = new Padding(2, 3, 2, 3);
            email.Name = "email";
            email.Size = new Size(137, 26);
            email.TabIndex = 28;
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Font = new Font("Calibri", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label16.ForeColor = Color.White;
            label16.Location = new Point(182, 135);
            label16.Margin = new Padding(2, 0, 2, 0);
            label16.Name = "label16";
            label16.Size = new Size(48, 21);
            label16.TabIndex = 27;
            label16.Text = "Email";
            // 
            // sdt
            // 
            sdt.BorderStyle = BorderStyle.FixedSingle;
            sdt.Enabled = false;
            sdt.Location = new Point(18, 156);
            sdt.Margin = new Padding(2, 3, 2, 3);
            sdt.Name = "sdt";
            sdt.Size = new Size(137, 26);
            sdt.TabIndex = 26;
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Font = new Font("Calibri", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label17.ForeColor = Color.White;
            label17.Location = new Point(18, 135);
            label17.Margin = new Padding(2, 0, 2, 0);
            label17.Name = "label17";
            label17.Size = new Size(103, 21);
            label17.TabIndex = 25;
            label17.Text = "Số điện thoại";
            // 
            // TenTK
            // 
            TenTK.BorderStyle = BorderStyle.FixedSingle;
            TenTK.Enabled = false;
            TenTK.Location = new Point(182, 49);
            TenTK.Margin = new Padding(2, 3, 2, 3);
            TenTK.Name = "TenTK";
            TenTK.Size = new Size(137, 26);
            TenTK.TabIndex = 24;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Calibri", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label12.ForeColor = Color.White;
            label12.Location = new Point(182, 28);
            label12.Margin = new Padding(2, 0, 2, 0);
            label12.Name = "label12";
            label12.Size = new Size(105, 21);
            label12.TabIndex = 23;
            label12.Text = "Tên Tài khoản";
            // 
            // sotien
            // 
            sotien.Enabled = false;
            sotien.Font = new Font("Calibri", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            sotien.ImeMode = ImeMode.Alpha;
            sotien.Increment = new decimal(new int[] { 50000, 0, 0, 0 });
            sotien.Location = new Point(537, 117);
            sotien.Margin = new Padding(2, 3, 2, 3);
            sotien.Maximum = new decimal(new int[] { 10000000, 0, 0, 0 });
            sotien.Minimum = new decimal(new int[] { 50000, 0, 0, 0 });
            sotien.Name = "sotien";
            sotien.Size = new Size(145, 28);
            sotien.TabIndex = 22;
            sotien.TextAlign = HorizontalAlignment.Center;
            sotien.ThousandsSeparator = true;
            sotien.Value = new decimal(new int[] { 50000, 0, 0, 0 });
            // 
            // loaiGD
            // 
            loaiGD.Enabled = false;
            loaiGD.FlatStyle = FlatStyle.Flat;
            loaiGD.FormattingEnabled = true;
            loaiGD.Items.AddRange(new object[] { " Nhận tiền", " Chuyển tiền" });
            loaiGD.Location = new Point(537, 69);
            loaiGD.Margin = new Padding(2, 3, 2, 3);
            loaiGD.Name = "loaiGD";
            loaiGD.Size = new Size(146, 26);
            loaiGD.TabIndex = 21;
            loaiGD.SelectedIndexChanged += loaiGD_SelectedIndexChanged;
            // 
            // ThemTK
            // 
            ThemTK.BackColor = Color.FromArgb(192, 255, 192);
            ThemTK.Enabled = false;
            ThemTK.FlatStyle = FlatStyle.Popup;
            ThemTK.ForeColor = Color.Black;
            ThemTK.Location = new Point(537, 155);
            ThemTK.Margin = new Padding(2, 3, 2, 3);
            ThemTK.Name = "ThemTK";
            ThemTK.Size = new Size(145, 32);
            ThemTK.TabIndex = 10;
            ThemTK.Text = "Thêm Tài khoản";
            ThemTK.UseVisualStyleBackColor = false;
            ThemTK.Click += ThemTK_Click;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Calibri", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label11.ForeColor = Color.White;
            label11.Location = new Point(537, 99);
            label11.Margin = new Padding(2, 0, 2, 0);
            label11.Name = "label11";
            label11.Size = new Size(59, 21);
            label11.TabIndex = 18;
            label11.Text = "Số tiền";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Calibri", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label10.ForeColor = Color.White;
            label10.Location = new Point(537, 47);
            label10.Margin = new Padding(2, 0, 2, 0);
            label10.Name = "label10";
            label10.Size = new Size(104, 21);
            label10.TabIndex = 17;
            label10.Text = "Loại giao dịch";
            // 
            // ngayGD
            // 
            ngayGD.CalendarTitleBackColor = Color.FromArgb(230, 255, 242);
            ngayGD.Enabled = false;
            ngayGD.Format = DateTimePickerFormat.Short;
            ngayGD.Location = new Point(357, 120);
            ngayGD.Margin = new Padding(2, 3, 2, 3);
            ngayGD.Name = "ngayGD";
            ngayGD.Size = new Size(146, 26);
            ngayGD.TabIndex = 10;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Calibri", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label9.ForeColor = Color.White;
            label9.Location = new Point(353, 99);
            label9.Margin = new Padding(2, 0, 2, 0);
            label9.Name = "label9";
            label9.Size = new Size(111, 21);
            label9.TabIndex = 15;
            label9.Text = "Ngày giao dịch";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Calibri", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label8.ForeColor = Color.White;
            label8.Location = new Point(357, 47);
            label8.Margin = new Padding(2, 0, 2, 0);
            label8.Name = "label8";
            label8.Size = new Size(99, 21);
            label8.TabIndex = 14;
            label8.Text = "Mã giao dịch";
            // 
            // maGD
            // 
            maGD.BorderStyle = BorderStyle.FixedSingle;
            maGD.Enabled = false;
            maGD.Location = new Point(357, 69);
            maGD.Margin = new Padding(2, 3, 2, 3);
            maGD.Name = "maGD";
            maGD.Size = new Size(145, 26);
            maGD.TabIndex = 13;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Calibri", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.ForeColor = Color.White;
            label7.Location = new Point(353, 28);
            label7.Margin = new Padding(2, 0, 2, 0);
            label7.Name = "label7";
            label7.Size = new Size(245, 21);
            label7.TabIndex = 12;
            label7.Text = "THÔNG TIN GIAO DỊCH ĐẦU TIÊN";
            // 
            // CCCD
            // 
            CCCD.BorderStyle = BorderStyle.FixedSingle;
            CCCD.Enabled = false;
            CCCD.Location = new Point(18, 49);
            CCCD.Margin = new Padding(2, 3, 2, 3);
            CCCD.Name = "CCCD";
            CCCD.Size = new Size(137, 26);
            CCCD.TabIndex = 11;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Calibri", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.ForeColor = Color.White;
            label6.Location = new Point(18, 28);
            label6.Margin = new Padding(2, 0, 2, 0);
            label6.Name = "label6";
            label6.Size = new Size(69, 21);
            label6.TabIndex = 10;
            label6.Text = "Số CCCD";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI Black", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.FromArgb(128, 64, 0);
            label5.Location = new Point(15, 3);
            label5.Margin = new Padding(2, 0, 2, 0);
            label5.Name = "label5";
            label5.Size = new Size(168, 25);
            label5.TabIndex = 0;
            label5.Text = "TÀI KHOẢN MỚI";
            // 
            // panel2
            // 
            panel2.BackColor = Color.FromArgb(117, 84, 174);
            panel2.Controls.Add(missingValue);
            panel2.Controls.Add(solanGDxoa);
            panel2.Controls.Add(soduTKxoa);
            panel2.Controls.Add(label13);
            panel2.Controls.Add(label14);
            panel2.Controls.Add(NgaylapTKxoa);
            panel2.Controls.Add(TenTKxoa);
            panel2.Controls.Add(label3);
            panel2.Controls.Add(label2);
            panel2.Controls.Add(Xoa);
            panel2.Controls.Add(Them);
            panel2.Controls.Add(ID);
            panel2.Controls.Add(label4);
            panel2.Dock = DockStyle.Top;
            panel2.Location = new Point(2, 3);
            panel2.Margin = new Padding(2, 3, 2, 3);
            panel2.Name = "panel2";
            panel2.Size = new Size(718, 127);
            panel2.TabIndex = 3;
            // 
            // missingValue
            // 
            missingValue.AutoSize = true;
            missingValue.Font = new Font("Segoe UI", 8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            missingValue.ForeColor = Color.Yellow;
            missingValue.Location = new Point(15, 109);
            missingValue.Margin = new Padding(2, 0, 2, 0);
            missingValue.Name = "missingValue";
            missingValue.Size = new Size(374, 19);
            missingValue.TabIndex = 15;
            missingValue.Text = "Số tài khoản là chuỗi bắt đầu bằng 'IT' và 4 chữ số theo sau";
            missingValue.Visible = false;
            missingValue.Click += missingValue_Click;
            // 
            // solanGDxoa
            // 
            solanGDxoa.Enabled = false;
            solanGDxoa.Location = new Point(457, 84);
            solanGDxoa.Margin = new Padding(2, 3, 2, 3);
            solanGDxoa.Name = "solanGDxoa";
            solanGDxoa.Size = new Size(163, 26);
            solanGDxoa.TabIndex = 14;
            // 
            // soduTKxoa
            // 
            soduTKxoa.Enabled = false;
            soduTKxoa.Location = new Point(457, 37);
            soduTKxoa.Margin = new Padding(2, 3, 2, 3);
            soduTKxoa.Name = "soduTKxoa";
            soduTKxoa.Size = new Size(163, 26);
            soduTKxoa.TabIndex = 13;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Calibri", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label13.ForeColor = SystemColors.ControlLightLight;
            label13.Location = new Point(457, 63);
            label13.Margin = new Padding(2, 0, 2, 0);
            label13.Name = "label13";
            label13.Size = new Size(118, 21);
            label13.TabIndex = 12;
            label13.Text = "Số lần giao dịch";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Calibri", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label14.ForeColor = SystemColors.ControlLightLight;
            label14.Location = new Point(457, 12);
            label14.Margin = new Padding(2, 0, 2, 0);
            label14.Name = "label14";
            label14.Size = new Size(121, 21);
            label14.TabIndex = 11;
            label14.Text = "Số dư Tài khoản";
            // 
            // NgaylapTKxoa
            // 
            NgaylapTKxoa.CalendarTitleBackColor = Color.FromArgb(230, 255, 242);
            NgaylapTKxoa.Enabled = false;
            NgaylapTKxoa.Format = DateTimePickerFormat.Short;
            NgaylapTKxoa.Location = new Point(239, 84);
            NgaylapTKxoa.Margin = new Padding(2, 3, 2, 3);
            NgaylapTKxoa.Name = "NgaylapTKxoa";
            NgaylapTKxoa.Size = new Size(163, 26);
            NgaylapTKxoa.TabIndex = 4;
            // 
            // TenTKxoa
            // 
            TenTKxoa.Enabled = false;
            TenTKxoa.Location = new Point(239, 37);
            TenTKxoa.Margin = new Padding(2, 3, 2, 3);
            TenTKxoa.Name = "TenTKxoa";
            TenTKxoa.Size = new Size(163, 26);
            TenTKxoa.TabIndex = 9;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Calibri", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = SystemColors.ControlLightLight;
            label3.Location = new Point(239, 63);
            label3.Margin = new Padding(2, 0, 2, 0);
            label3.Name = "label3";
            label3.Size = new Size(140, 21);
            label3.TabIndex = 8;
            label3.Text = "Ngày lập Tài khoản";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Calibri", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = SystemColors.ControlLightLight;
            label2.Location = new Point(239, 12);
            label2.Margin = new Padding(2, 0, 2, 0);
            label2.Name = "label2";
            label2.Size = new Size(105, 21);
            label2.TabIndex = 7;
            label2.Text = "Tên Tài khoản";
            // 
            // Xoa
            // 
            Xoa.BackColor = Color.FromArgb(255, 192, 192);
            Xoa.Location = new Point(79, 73);
            Xoa.Margin = new Padding(2, 3, 2, 3);
            Xoa.Name = "Xoa";
            Xoa.Size = new Size(57, 25);
            Xoa.TabIndex = 5;
            Xoa.Text = "Xóa";
            Xoa.UseVisualStyleBackColor = false;
            Xoa.Click += button2_Click;
            // 
            // Them
            // 
            Them.BackColor = Color.FromArgb(192, 255, 192);
            Them.Location = new Point(15, 73);
            Them.Margin = new Padding(2, 3, 2, 3);
            Them.Name = "Them";
            Them.Size = new Size(58, 25);
            Them.TabIndex = 4;
            Them.Text = "Thêm";
            Them.UseVisualStyleBackColor = false;
            Them.Click += button1_Click;
            // 
            // ID
            // 
            ID.Location = new Point(15, 45);
            ID.Margin = new Padding(2, 3, 2, 3);
            ID.Name = "ID";
            ID.Size = new Size(181, 26);
            ID.TabIndex = 3;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Calibri", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.ForeColor = SystemColors.ControlLightLight;
            label4.Location = new Point(15, 23);
            label4.Margin = new Padding(2, 0, 2, 0);
            label4.Name = "label4";
            label4.Size = new Size(137, 21);
            label4.TabIndex = 2;
            label4.Text = "Nhập số Tài khoản";
            // 
            // HoSoTK
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(tabControl1);
            Margin = new Padding(2, 3, 2, 3);
            Name = "HoSoTK";
            Size = new Size(703, 452);
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            tabControl1.ResumeLayout(false);
            tabPage1.ResumeLayout(false);
            flowLayoutPanel1.ResumeLayout(false);
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            tabPage2.ResumeLayout(false);
            tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView2).EndInit();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)sotien).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private TabControl tabControl1;
        private TabPage tabPage1;
        private TabPage tabPage2;
        private ComboBox comboBox1;
        private Panel panel1;
        private Label label1;
        private FlowLayoutPanel flowLayoutPanel1;
        private Label TextName;
        private Label TimeName;
        private TextBox EnterTN;
        private DateTimePicker ChonNgay1;
        private DateTimePicker ChonNgay2;
        private DataGridView dataGridView1;
        private Panel panel2;
        private Label label4;
        private TextBox ID;
        private Button Xoa;
        private Button Them;
        private Label label2;
        private DateTimePicker NgaylapTKxoa;
        private TextBox TenTKxoa;
        private Label label3;
        private DataGridView dataGridView2;
        private Panel panel3;
        private Label label5;
        private TextBox maGD;
        private Label label7;
        private TextBox CCCD;
        private Label label6;
        private DateTimePicker ngayGD;
        private Label label9;
        private Label label8;
        private Label label11;
        private Label label10;
        private Button ThemTK;
        private TextBox solanGDxoa;
        private TextBox soduTKxoa;
        private Label label13;
        private Label label14;
        private Button button6;
        private Button button5;
        private Label label15;
        private Button Find;
        private ComboBox loaiGD;
        private NumericUpDown sotien;
        private DataGridViewTextBoxColumn AccountID;
        private DataGridViewTextBoxColumn AccountName;
        private DataGridViewTextBoxColumn Balance;
        private DataGridViewTextBoxColumn TransactionNumber;
        private DataGridViewTextBoxColumn AccountDate;
        private TextBox TenTK;
        private Label label12;
        private TextBox diachi;
        private DateTimePicker Birth;
        private Label label18;
        private Label label19;
        private TextBox email;
        private Label label16;
        private TextBox sdt;
        private Label label17;
        private Label label20;
        private Label missingValue;
        private Label label21;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
    }
}
